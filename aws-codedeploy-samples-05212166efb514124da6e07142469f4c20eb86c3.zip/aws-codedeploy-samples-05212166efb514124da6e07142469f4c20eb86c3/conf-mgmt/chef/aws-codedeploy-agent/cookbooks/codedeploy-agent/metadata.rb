name	'codedeploy-agent'
recipe	'codedeploy-agent::default', 'Fetches, installs, and starts the AWS CodeDeplot host agent'
