# These are here just for testing only.
file_cache_path "/etc/chef"
cookbook_path "/etc/chef/cookbooks"
json_attribs "/etc/chef/node.json"
